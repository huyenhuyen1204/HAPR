import java.io.*;
import java.util.List;

/**
 * Created by CCNE on 03/12/2020.
 */
public class Bank {
    List<Customer> customerList;

    public void readCustomerList(InputStream inputStream) {
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        StringBuilder data = new StringBuilder();
        int x;
        char c;
        try {
            while((x = inputStreamReader.read())!=-1) {
                // converts integer to character
                c = (char)x;
                data.append(c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(data);
        String[] lines = data.toString().split("\n");


        for (String line :lines) {
            String[] parseLine = line.split(" ");

            if (!('0' <= parseLine[0].charAt(0) && parseLine[0].charAt(0) <= '9')) {
                StringBuilder name = new StringBuilder();
                for (int i = 0; i < parseLine.length - 1; ++i) {
                    name.append(parseLine[i]);
                    if (i < parseLine.length - 2) {
                        name.append(" ");
                    }
                }

                String id = parseLine[parseLine.length - 1].substring(0, 9);
                Long idNumber = Long.parseLong(id);

                customerList.add(new Customer(idNumber, name.toString()));
                System.out.println(name.toString() + "hihi");
                System.out.println(id);
            }
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        Bank bank = new Bank();
        bank.readCustomerList(new FileInputStream("C:\\Users\\CCNE\\IdeaProjects\\Week12\\src\\test.txt"));
    }
}
