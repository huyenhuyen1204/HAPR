public class BankException extends Exception {
    /**
     * This is comment.
     */
    private static final long serialVersionUID = 1L;

    /**
     * This is comment.
     */
    public BankException(String msg) {
        super(msg);
    }
}
